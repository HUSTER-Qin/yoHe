import { mount, shallowMount, createLocalVue } from '@vue/test-utils';
import VueRouter from 'vue-router';
import { routes } from '../../src/router/index';

import App from '@/App.vue';
import Count from '../../src/components/Count';

const localVue = createLocalVue();

localVue.component(Count.name, Count);
localVue.use(VueRouter);
describe('num data', () => {
  // 现在挂载组件，你便得到了这个包裹器
  const router = new VueRouter({ routes });

  it('路由到About页面', done => {
    router.push('/about').then(() => {
      // console.log('4', wrapper.html())
      expect(router.currentRoute.path).toMatch('/about');
      done();
    });
  });
  // 测试 data 赋值
  it(' 测试data 赋值', async () => {
    const wrapper = mount(App, {
      localVue,
      router,
    });
    await wrapper.setData({ num: 1 });
    expect(wrapper.vm.num).toBe(1);
    expect(wrapper.find('h5').text()).toMatch('1');
  });
  it('由 父 组件内的 h1 触发点击事件，更新count为11', () => {
    const wrapper = shallowMount(App, {
      localVue,
      router,
    });
    wrapper.setData({ num: 10 });
    const button = wrapper.find('h1');
    expect(button.exists()).toBe(true);
    button.trigger('click');
    expect(wrapper.vm.$data.num).toBe(11);
  });
  it('由子组件触发 emit，更新count为22', async () => {
    const wrapper = mount(App, {
      localVue,
      router,
    });
    wrapper.setData({ num: 21 });
    const count = wrapper.findComponent(Count);
    expect(count.exists()).toBe(true);
    count.vm.$emit('add-count');
    expect(wrapper.vm.$data.num).toBe(22);
  });

  it('由子组件内的button触发点击事件，更新count为11', () => {
    const wrapper = mount(App, {
      localVue,
      router,
    });
    wrapper.setData({ num: 10 });
    const count = wrapper.findComponent(Count);

    expect(count.exists()).toBe(true);
    expect(
      wrapper
        .findComponent({ name: 'Count' })
        .find('#button')
        .text(),
    ).toEqual('子组件button');
    count.find('#button').trigger('click');
    expect(wrapper.vm.$data.num).toBe(11);
  });

  // props

  it('默认prop值为10', () => {
    const wrapper = mount(Count, { localVue });
    expect(wrapper.props().countNum).toBe(10);
    expect(wrapper.props('countNum')).toBe(10);
    expect(wrapper.find('h3').text()).toMatch('10');
  });

  it('设置propData.countNum 值为11', () => {
    const wrapper = mount(Count, {
      localVue,
      propsData: { countNum: 11 },
    });
    expect(wrapper.props().countNum).toBe(11);
    expect(wrapper.props('countNum')).toBe(11);
    expect(wrapper.find('h3').text()).toMatch('11');
  });

  it('修改props.countNum 值为12', async () => {
    const wrapper = mount(Count, { localVue });
    await wrapper.setProps({ countNum: 12 });
    expect(wrapper.props().countNum).toBe(12);
    expect(wrapper.props('countNum')).toBe(12);
    expect(wrapper.find('h3').text()).toMatch('12');
  });

  // 测试 子组件事件 调用 父组件 事件
  // it('由子组件内的button触发点击事件，更新count为11', () => {
  //   const wrapper = mount(App, {
  //     localVue,
  //     router,
  //   });
  //   const addCount = jest.fn();
  //   wrapper.setMethods({ addCount });
  //   wrapper.findComponent(Count).vm.$emit('add-count');
  //   expect(addCount).toBeCalled();
  //   expect(addCount).toBeCalledTimes(1);
  // });
});
