<template>
  <div>
    <h2 @click="add" id="button">子组件button</h2>
    <h3>{{ countNum }}</h3>
  </div>
</template>

<script>
import Api from '@/api';
export default {
  name: 'Count',
  data() {
    return {
      msg: '',
    };
  },
  props: {
    countNum: {
      type: Number,
      default: 10,
    },
  },
  methods: {
    add() {
      this.$emit('add-count');
    },
    getUser() {
      Api.getUsers().then(res => {
        if (Array.isArray(res)) {
          this.msg = res[0].username;
        }
      });
    },
  },
  created() {
    this.getUser();
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
