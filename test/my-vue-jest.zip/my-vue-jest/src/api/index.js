import axios from 'axios';

export default {
  getUsers: params => axios.get('https://jsonplaceholder.typicode.com/users', params),
};
