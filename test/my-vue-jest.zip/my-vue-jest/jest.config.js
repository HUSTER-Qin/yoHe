module.exports = {
  preset: '@vue/cli-plugin-unit-jest',
  moduleNameMapper: {
    '^@/(.*)$': '/Users/qinsong/base/my-vue-jest/src/$1',
  },
};
